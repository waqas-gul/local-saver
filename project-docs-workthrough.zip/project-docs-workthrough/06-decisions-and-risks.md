# 06 — Decisions, Risks and Open Questions

| Field | Value |
|---|---|
| Document status | LIVING DOCUMENT |
| Last updated | 2026-09-23 (CR-001: owner kept automatic same-network visibility) |

---

## 1. How this log works

### 1.1 Decision statuses

| Status | Meaning |
|---|---|
| `PROPOSED` | Recommended, awaiting owner approval. Must not be implemented yet. |
| `CONDITIONAL` | Approved in principle, pending a named spike or answer |
| `ACCEPTED` | Approved by the owner. Implementation must follow it. |
| `SUPERSEDED` | Replaced by a later decision (link to its change record) |
| `REJECTED` | Considered and declined (kept for history) |

### 1.2 Changing an accepted decision

**Never change an accepted decision silently.** Add a change record under §5 and update the decision's status:

```text
CR-NNN — <short title> (changes DEC-XXX)
Date:
Previous decision:
Reason for change:
New decision:
Impact on existing implementation (code, data, migrations, docs):
Migration / rollback plan:
Approved by:
```

---

## 2. Decision log

### DEC-001 — Web framework and UI stack

- **Decision:** keep Next.js 16 App Router (16.3.5 installed), React 19, TypeScript (strict), Tailwind CSS v4 and shadcn/ui.
- **Reason:** already scaffolded. One deployable for UI and API. shadcn/ui gives accessible Radix-based components copied into the repo (no runtime lock-in).
- **Alternatives considered:** React Router/Remix, SvelteKit, a separate SPA plus an API service (Hono/Fastify).
- **Risks:** Next.js 16 differs from older docs and libraries (`proxy.ts`, async request APIs). Follow the bundled docs (RISK-016).
- **Status:** PROPOSED

### DEC-002 — Same-network model: discovery is not authorization *(rejected by the owner)*

> Kept for history. Replaced by DEC-031 through [CR-001](#cr-001--keep-automatic-same-network-visibility-changes-dec-002-and-dec-003).

- **Decision (as proposed):** network signals only **suggest** nearby rooms. Content access requires **membership**, obtained by approval, nearby PIN, an owner-opened join window, an invite/QR secret, or workspace membership. Membership persists across networks.
- **Reason (as proposed):** public-IP grouping yields false positives (CGNAT, campus, café, VPN, relays) and false negatives (dual-stack, relays). Browsers block LAN identification. The same Wi-Fi is not a trust boundary. See [03 §2](03-security-and-network-design.md#2-same-network-detection--technical-analysis).
- **Alternatives considered:** automatic visibility for the same public IP, with or without crowding heuristics; WebRTC LAN proof; native apps with mDNS (Q-025).
- **Status:** **REJECTED** by the owner on 2026-09-23. The product keeps automatic same-network visibility with no approval step (DEC-031).

### DEC-003 — Network hint derivation, privacy and retention *(superseded)*

> Replaced by DEC-032 through [CR-001](#cr-001--keep-automatic-same-network-visibility-changes-dec-002-and-dec-003). The derivation (keyed HMAC, IPv4 /32, IPv6 /64) carries over. The discovery-only purpose, the 2 h / 24 h hint lifetimes and the crowding threshold of 12 do not.

- **Decision (as proposed):** `hint = HMAC-SHA256(secret key, normalized IP)`, where IPv4 is /32 and IPv6 is /64. Observations live for 2 h and are deleted after 24 h. Crowding threshold 12 distinct devices per 24 h. iCloud Private Relay ranges mark a network `shared_egress`.
- **Status:** **SUPERSEDED** by DEC-032 (2026-09-23)

### DEC-004 — Trusted client-IP source and origin lock

- **Decision:**
  - Production traffic must pass through Cloudflare. The origin rejects requests without the secret header injected by a Cloudflare Transform Rule.
  - Only then is `CF-Connecting-IP` trusted. `X-Forwarded-For` and `X-Real-IP` are ignored.
  - On a VPS, prefer Cloudflare Tunnel.
- **Reason:** `NextRequest.ip` no longer exists. Forwarded headers are client-controlled unless the proxy chain is controlled. **Under DEC-031 the trusted IP decides who sees local content**, so a spoofed IP would expose any network's local content. Spoofing would also allow rate-limit evasion.
- **Alternatives considered:** trusting the host's `X-Forwarded-For` (unverified), authenticated origin pulls with mTLS (VPS only), Cloudflare IP allow-listing (VPS only).
- **Status:** PROPOSED — verified in SP-01

### DEC-005 — Device identity via Supabase anonymous sign-ins

- **Decision:**
  - Each browser signs in anonymously (CAPTCHA/Turnstile required) and registers an `app.devices` row.
  - Anonymous users inactive for 30 days are deleted.
  - Upgrading to a permanent account keeps the same user ID.
  - **Share-link viewers do not create Supabase users.**
- **Reason:** one `auth.uid()` for anonymous and permanent users, native Realtime authorization, a built-in upgrade path.
- **Alternatives considered:** own device cookies plus custom JWTs minted with a Supabase-imported signing key (lower MAU cost, more code; kept as an exit ramp). Third-party auth providers (unnecessary).
- **Risks:** MAU billing for anonymous devices (RISK-006). CAPTCHA applies to every Supabase auth flow once enabled.
- **Status:** PROPOSED

### DEC-006 — Data-access boundary

- **Decision:** application tables live in the private `app` schema, **not exposed** through the Data API. Only the Next.js server (role `app_server`) reads and writes them. Browsers use Supabase only for Auth and Realtime. RLS is enabled everywhere with server-only policies as defense in depth.
- **Reason:** a single enforcement point for authorization, entitlements, quotas and rate limits. Clients cannot bypass the API through PostgREST.
- **Alternatives considered:** browser supabase-js with RLS for everything (logic spread across policies, entitlements and rate limits bypassable, hard to test). Server calls through PostgREST with the secret key (no multi-statement transactions without RPC).
- **Status:** PROPOSED

### DEC-007 — Migrations and query layer

- **Decision:** SQL-first migrations with the Supabase CLI. Kysely with generated types for server queries over the Supavisor pooler (session mode for a long-running server). pgTAP for database tests.
  - **Fallback** if the host blocks outbound Postgres TCP: supabase-js with the secret key calling `SECURITY DEFINER` RPC functions in a dedicated, locked-down schema.
- **Reason:** SQL-native features (RLS, realtime triggers, pg_cron) are central. Generated types avoid drift.
- **Alternatives considered:** Drizzle ORM (acceptable if preferred, with SQL migrations staying authoritative), Prisma (weaker fit for SQL-first, heavier runtime).
- **Status:** PROPOSED — connectivity verified in SP-01

### DEC-008 — API style

- **Decision:** versioned JSON route handlers under `/api/v1`. Thin handlers call server-only services. zod contracts shared with the client. Server Actions are **not** used for security-critical or upload flows.
- **Reason:** explicit HTTP semantics, per-endpoint rate limits and CSRF policy, testable with HTTP tools. Server Actions are queued, default to a 1 MB body, and allow requests with no `Origin` header (with a warning).
- **Alternatives considered:** Server Actions everywhere, tRPC, a separate API service.
- **Status:** PROPOSED

### DEC-009 — File storage and transfer path

- **Decision:** Cloudflare R2 private buckets. Browsers upload directly with presigned PUT (multipart for large files) and download through presigned GET (60 s) issued after authorization. **File bytes never pass through Next.js or Supabase.**
- **Reason:** free egress, S3 compatibility, no web-tier bandwidth, memory or timeout pressure. The Next.js proxy buffers bodies up to 10 MB.
- **Alternatives considered:** Supabase Storage (egress billed), proxying through Next.js, a Cloudflare Worker download gateway (later option).
- **Risks:** no POST policies, so verification happens after upload (RISK-010). Presigned URLs are bearer tokens (RISK-009). Presigning only works on the S3 endpoint.
- **Status:** PROPOSED — semantics verified in SP-02

### DEC-010 — Object key and metadata strategy

- **Decision:** keys `{d7|d30|d90|ws}/{yyyy}/{mm}/{dd}/{fileUuid}` with no PII. `Content-Type`, `Content-Disposition: attachment` and `Cache-Control` set at upload through signed headers. Lifecycle backstop rules per prefix.
- **Reason:** lifecycle backstops need prefixes, reconciliation lists by date, and R2 response-header overrides are uncertain.
- **Alternatives considered:** per-user or per-room prefixes (PII-adjacent, no benefit), flat keys (no backstop).
- **Status:** PROPOSED

### DEC-011 — Realtime approach

- **Decision:**
  - Supabase Realtime **private** channels.
  - Local mode uses one topic per network space, `net:{spaceId}`. A device may join it only while the server has recorded it as **present** on that space (DEC-032). Pro/Team rooms use `room:{roomId}` with membership checks.
  - **Broadcast emitted by database triggers** with ID-only payloads. Presence for devices on the network ("N devices here now").
  - **No Postgres Changes. No client-sent broadcasts.**
  - Link-viewer pages poll.
- **Reason:** Postgres Changes is single-threaded with per-subscriber checks. Trigger emission is transactional. Replay storage holds no content. Authorization stays simple.
- **Alternatives considered:** Postgres Changes, own WebSocket server, Ably/Pusher, Cloudflare Durable Objects.
- **Risks:** channel authorization is cached per connection, so a device that left a network can receive ID-only signals until its token refreshes (RISK-007). Message retention (RISK-023).
- **Status:** PROPOSED — verified in SP-03. Revised 2026-09-23 for CR-001 (network topics instead of nearby-room membership).

### DEC-012 — Content model

- **Decision:** a **share** (a bundle of files, or one text item) → `files` / `text_items`. Each share has a scope:
  - `network`: posted to a network space and visible to devices currently on that network (local mode, DEC-031).
  - `link_only`: visible only to its creator and to holders of its links (Phase 2).
  - `room`: posted to a Pro private room or a Team workspace room (Phase 4–5).

  `share_links` grant remote access to one share, or read-only access to a private or workspace room (Pro/Team).
- **Reason:** bundles map to multi-file sends and single links. Per-share lifecycle (expiry, burn) matches user intent. Local mode needs no room object, because a network has no owner or members.
- **Alternatives considered:** flat items (multi-file links harder), links as the only container, modelling each network as a room with members (the rejected DEC-002).
- **Status:** PROPOSED. Revised 2026-09-23 for CR-001.

### DEC-013 — Remote link format and viewer sessions

- **Decision:**
  - URL `https://{domain}/s/{linkId}#k={secret}`: a 96-bit link ID and a 256-bit secret stored as an HMAC.
  - Unlocking creates an httpOnly link session and a grant (≤ 12 h). Viewers get no Supabase user.
  - State is revealed only after the secret is proven.
  - Share pages are `noindex`, `no-referrer`, with no third-party scripts.
- **Reason:** keeps secrets out of logs and referrers, safe against unfurlers, cost-efficient, revocable.
- **Alternatives considered:** secret in the path (logged everywhere), opaque path-only token, requiring viewer sign-in.
- **Status:** PROPOSED

### DEC-014 — Short share codes

- **Decision:** 10-character Crockford Base32 (50 bits), HMAC-stored. Default validity 1 h (Free ≤ 24 h, Pro ≤ 7 days). Rate limits with Turnstile escalation. Resolving creates a grant and never reveals the link secret.
- **Reason:** typable yet brute-force resistant at scale ([03 §4.4](03-security-and-network-design.md#44-short-codes-dec-014)).
- **Alternatives considered:** 8 characters (≈ 0.9 expected hits per day under a 10⁶ guesses/day attack with 10⁶ active codes), 6-digit global codes (unsafe), word lists (longer).
- **Status:** PROPOSED

### DEC-015 — One-time download semantics

- **Decision:** **burn on claim.** The first non-creator download request atomically claims the share. Only the claimant (device or link session) may obtain URLs during a grace window (15 min plus a size-based extension, ≤ 6 h, ≤ 3 issuances per file). Then the content ends and objects are deleted. POST only. No previews for burn shares.
- **Reason:** completion is unobservable. Completion-based consumption is exploitable (abort at 99%) and racy. Bots follow links.
- **Alternatives considered:** completion detection through a Worker proxy (still exploitable by partial downloads), single-use presigned URLs (not supported by SigV4 semantics).
- **Status:** PROPOSED — changes REQ-004 (owner sign-off)

### DEC-016 — Expiry enforcement and cleanup

- **Decision:**
  - Request-time checks are authoritative.
  - `app.end_share()` is the only path to end content: it nulls text, enqueues object deletions and releases quota.
  - pg_cron performs state transitions. An outbox plus janitor deletes objects.
  - R2 lifecycle rules are the backstop. Reconciliation jobs catch drift.
- **Reason:** correctness independent of job latency, no orphan objects, auditable.
- **Alternatives considered:** relying on lifecycle rules (≈ 24 h lag), synchronous deletion in request paths (fragile).
- **Status:** PROPOSED

### DEC-017 — Scheduler and janitor runtime

- **Decision:** Supabase Cron (pg_cron) for SQL jobs. The storage janitor is a Supabase Edge Function invoked by pg_cron through pg_net with a Vault-stored secret. A Cloudflare Worker with a Cron Trigger and R2 binding is the documented alternative.
- **Reason:** jobs sit next to the data. Nothing runs in the background on the web host.
- **Alternatives considered:** host cron calling an API route, GitHub Actions schedules (can be delayed), a Cloudflare Worker.
- **Status:** PROPOSED — Edge Function execution limits verified before Phase 3

### DEC-018 — Entitlements model and enforcement location

- **Decision:** plans defined in typed code, overrides in the database, resolved per request on the server, enforced in services on every write path. Snapshots stored on shares and links. **The uploader's plan** governs local, link-only and private-room shares. **The workspace plan** governs workspace rooms.
- **Reason:** server-side enforcement, predictable behaviour after plan changes.
- **Alternatives considered:** plans only in database rows (harder to type and test), client-side gating (insecure).
- **Status:** PROPOSED

### DEC-019 — Storage quota accounting

- **Decision:** a per-subject ledger. Atomic conditional reservation at init, commit on verification, release on failure or end. Daily reconciliation.
- **Reason:** race-free quota enforcement without table-wide locks.
- **Alternatives considered:** `SUM()` at upload time (slow, racy). R2 has no per-user quotas.
- **Status:** PROPOSED

### DEC-020 — Rate limiting layers

- **Decision:** a coarse Cloudflare edge rule plus Postgres fixed-window counters (`app.rate_limit_hit`) keyed by device, user, network key, link and room. Turnstile escalation. Move to Redis only if database load requires it.
- **Reason:** no new vendor for the MVP, works across instances, precise keys.
- **Alternatives considered:** in-memory limits (lost on restart, per instance), Upstash Redis from day one (extra vendor).
- **Status:** PROPOSED

### DEC-021 — Link password hashing

- **Decision:** Argon2id (m = 19 MiB, t = 2, p = 1) via `@node-rs/argon2`. PHC strings. Versioned grants. Attempt limits.
- **Reason:** OWASP-recommended, memory-hard, prebuilt Linux binaries.
- **Alternatives considered:** scrypt via `node:crypto` (fallback if native binaries fail on the host), bcrypt (72-byte input limit).
- **Status:** PROPOSED (Phase 4)

### DEC-022 — Hosting

- **Decision:** Hostinger managed Node.js web app behind Cloudflare, **only if SP-01 passes**. Otherwise a Hostinger VPS (Docker, Next.js `standalone`, Cloudflare Tunnel), or Vercel if the owner prefers managed hosting over operations work.
- **Reason:** owner preference and cost, but unverified platform behaviour is critical to security (client IP) and reliability.
- **Alternatives considered:** Vercel (a paid plan is needed for commercial use), Next.js on Cloudflare Workers via OpenNext (verify Next.js 16 support), Render, Fly.io, Railway.
- **Status:** CONDITIONAL — pending SP-01 and Q-012

### DEC-023 — Billing provider

- **Decision:** a **merchant of record** (Paddle, Lemon Squeezy or Polar) unless the business is in a Stripe-supported country and prefers to handle sales tax and VAT itself. Provider-agnostic subscription tables and an idempotent webhook log.
- **Reason:** a global consumer SaaS at low price points must handle VAT/GST. A merchant of record takes that on.
- **Alternatives considered:** Stripe Billing plus Stripe Tax. Stripe's own merchant-of-record offering (reported in private beta in 2026; verify availability).
- **Risks:** fees of about 5% + $0.50 per transaction on low prices (RISK-015).
- **Status:** PROPOSED — blocked on Q-005

### DEC-024 — No third-party ad or analytics scripts on content pages

- **Decision:** no ad networks, tag managers or third-party analytics on app, room, share, invite or code pages. Any Free-plan ads are limited to marketing pages or first-party promotions.
- **Reason:** third-party scripts can read shared text, file names and presigned URLs. Ad network policies often exclude file-hosting user content.
- **Alternatives considered:** sandboxed ad iframes (still privacy and performance costs).
- **Status:** PROPOSED (Q-011)

### DEC-025 — Content-safety posture

- **Decision:**
  - Downloads are attachment-only, from R2's origin.
  - Inline previews only for magic-byte-verified raster images via `<img>` (no `next/image` optimization). Text shown as escaped plain text.
  - Filename sanitization.
  - Executable/script uploads blocked for anonymous remote links until scanning exists.
  - Abuse reporting and takedown.
  - No public multi-scanner services for private files. Malware scanning in Phase 6.
- **Reason:** prevent XSS and phishing via user content, reduce malware distribution, protect privacy.
- **Status:** PROPOSED (Q-010)

### DEC-026 — Upload transport by size

- **Decision:** single presigned PUT for files ≤ 100 MB (Phase 1). Multipart for larger files (Phase 4): equal parts ≥ 16 MiB, resumable, verified with `ListParts`.
- **Reason:** simple for Free. R2's single-PUT limit is 5 GiB, and it has multipart part-size rules.
- **Status:** PROPOSED

### DEC-027 — Text items

- **Decision:** text lives in Postgres (hard cap 1 MB; Free 100 KB proposed). Versioned last-writer-wins edits with 409 on conflict. Content nulled at share end. No CRDT or collaborative editing.
- **Reason:** clipboard-style sharing doesn't need live co-editing. Simple and auditable.
- **Alternatives considered:** Yjs/CRDT live editing (complex), storing text in R2 (unnecessary).
- **Status:** PROPOSED (Q-021)

### DEC-028 — Environments and CI/CD

- **Decision:**
  - Environments: local (Supabase CLI), staging and production, each with separate Supabase projects, R2 buckets and hostnames.
  - GitHub Actions CI: typecheck, lint, unit, database tests, build, e2e.
  - Migrations go to staging automatically and to production with approval.
  - The host deploys only from a deploy branch fast-forwarded after CI and migrations succeed.
- **Reason:** the host auto-deploys from Git. Gating prevents untested deploys.
- **Status:** PROPOSED

### DEC-029 — Observability and redaction

- **Decision:** error monitoring (Sentry or equivalent) scrubbing URLs, fragments, cookies and tokens. Structured JSON logs (pino) with redaction. Uptime and cron-heartbeat monitoring. Alert catalogue in [08](08-deployment-and-operations.md#8-observability-and-alerting).
- **Status:** PROPOSED

### DEC-030 — Runtime and package manager

- **Decision:** Node.js 24 LTS on the host (22 LTS as fallback), pinned with `engines` and `.node-version`. pnpm pinned through `packageManager` to a version the host and CI support. Keep 12.4.2 only if SP-01 confirms support.
- **Reason:** Next.js 16 needs Node ≥ 20.9. The host offers 18/20/22/24. Lockfile format compatibility.
- **Status:** PROPOSED (SP-01, Q-024)

### DEC-031 — Local mode: automatic same-network visibility

- **Decision (the owner's product rule):**
  - **Same Wi-Fi/network:** anyone on that network automatically sees the files, text and images posted to it. No approval, PIN, QR code or link.
  - **Different network:** sees nothing automatically, not even that the content exists.
  - **Remote access:** only through an explicit share link, its QR code, or a short share code, and only to what was shared.
- **Reason:** this is the product's core promise. The owner explicitly declined approval-based sharing on 2026-09-23 (CR-001).
- **Alternatives considered:** DEC-002 (approval, PIN or open-join window, then remembered membership): rejected by the owner. WebRTC LAN proof: withdrawn (it needs another device online and can trigger a permission prompt). Native apps with mDNS: future option (Q-025).
- **Security implications:**
  - The network the server sees becomes the access rule for local content. That view must come only from a Cloudflare-verified IP (DEC-004) and must switch itself off wherever the server cannot tell networks apart (DEC-032).
  - Inherent residual risks, which no guard can remove: everyone physically on the Wi-Fi sees local content (RISK-025); different networks behind one undetected shared IP can see each other's local content (RISK-001); an IP reassigned by the ISP exposes content still live on it (RISK-026). See [03 §3.8](03-security-and-network-design.md#38-isolation-guarantees).
- **Status:** **ACCEPTED** (owner, 2026-09-23)

### DEC-032 — Network keys, dual-stack binding and fail-closed eligibility

- **Decision:**
  - `networkKey = HMAC-SHA256(secret, normalized IP)`: IPv4 /32, IPv6 /64, with IPv4-mapped and NAT64 forms normalized. Raw IPs are never stored. One **network space** per key.
  - The server derives the key **on every request** from the Cloudflare-verified client IP. No API accepts a network or space identifier from the client.
  - **Dual-stack binding (if SP-04 shows it works):** the client probes an IPv4-only and an IPv6-only hostname, and the server binds both keys to the device for 10 minutes, but only while the current request's own key is one of them.
  - A new local share goes into the uploader's **most specific** eligible space (IPv6 /64 if present, else IPv4). A device sees shares in every eligible space of its current network.
  - **Eligibility.** Only `ok` networks have local mode. The other statuses switch it off (fail closed):
    - `shared_egress`: iCloud Private Relay and Tor exit lists; VPN, hosting and (IPv4 only) mobile-carrier ASNs; an IPv4 bound to two or more IPv6 /64s within one hour.
    - `too_large`: more than 50 distinct devices in 24 h (Q-029).
    - `blocked`: operator action.
    - `unavailable`: no trusted or global IP.

    Fail closed covers both viewing and posting. Content already on a network is hidden until it becomes eligible again. Creators always keep access to their own shares.
  - **Presence:** recorded by the server, lasting 10 minutes after the device's last check-in. It authorizes the realtime topic and feeds the device count.
- **Reason:** makes DEC-031 as safe as a web app can make it. Clients cannot pick a network, and ambiguous networks fail closed instead of leaking.
- **Alternatives considered:**
  - Plain SHA-256: reversible.
  - IPv6 /56 grouping: groups more strangers.
  - A crowding threshold of 12 (DEC-003): too low now that ordinary office and café Wi-Fi is meant to work.
  - No guards: leaks immediately on mobile, VPN and relay IPs.
  - Remembering access after a device leaves: contradicts DEC-031.
- **Risks:** false negatives (RISK-013). Undetected shared IPs (RISK-001). Network keys are pseudonymous personal data.
- **Status:** PROPOSED — parameters set by SP-04 and Q-029

### DEC-033 — Local share permissions and remote reach

- **Decision:**
  - The uploader picks a destination: **This network** (the default when eligible) or **Link only** (Phase 2; never visible on any network). Pro/Team add private and workspace rooms.
  - Anyone currently on the network can view, download, copy text and report a local share. **Only its creator** can edit text, delete it, and create or revoke links (Q-021). Operators can block.
  - Creators always see their shares under **My uploads**, from any network, and can share them by link from there.
  - Remote links target **one share** (Free) or a **private or workspace room** (Pro/Team). **There is no link to a whole network's feed**: it would expose other people's local uploads off the network (Q-028).
  - Before posting, the UI states the audience: *"Visible to everyone on this network · 3 devices here now"*. A one-time notice explains that everyone on the same Wi-Fi, including guests, can see and download local posts.
- **Reason:** keeps the automatic model while ensuring nobody can delete or export someone else's local post, and that uploaders know who can see it.
- **Alternatives considered:** anyone present may delete or edit (vandalism on public Wi-Fi); network-wide remote links (exposes others' posts).
- **Status:** PROPOSED (Q-021, Q-028)

---

## 3. Risk register

Likelihood: L/M/H. Impact: L/M/H/Critical. Status: `OPEN` · `MITIGATING` · `ACCEPTED` · `CLOSED`.

| ID | Risk | Likelihood | Impact | Mitigation | Phase | Status |
|---|---|---|---|---|---|---|
| RISK-001 | Cross-network exposure: different networks behind one public IP that is not recognized as shared (small-ISP CGNAT, campus or enterprise NAT, VPNs missing from lists) see each other's local content. Inherent to DEC-031. | M (higher at low scale, before shared IPs are detected) | **Critical** | DEC-032 fail-closed guards: Private Relay and Tor lists, VPN/hosting/mobile-carrier ASNs, IPv4-with-several-IPv6 detection, large-network cap. Audience indicator (DEC-033). Report and takedown. Shorter default expiry (Q-030). Tests T-001 … T-010. SP-04 measures it. **Can be reduced, not eliminated.** | 0–1, 6 | OPEN |
| RISK-002 | Client-IP spoofing via forwarded headers or origin bypass. Under DEC-031 a forged IP would reveal **any network's local content**. | M | **Critical** | DEC-004 origin lock, Tunnel on VPS, spoofing tests from outside Cloudflare (T-008), production refuses the test IP override | 0–1 | OPEN |
| RISK-003 | Hostinger platform unknowns (timeouts, streaming, IP headers, pnpm 12, memory, restarts, outbound TCP) | M | H | SP-01 with pass/fail criteria, VPS or Vercel fallback (DEC-022) | 0 | OPEN |
| RISK-004 | Abuse of free anonymous hosting (malware, phishing, piracy, illegal content, spam) | H | **Critical** | Quotas, rate limits, Turnstile, executable policy, abuse reports, takedown, kill switches, scanning (Phase 6), public beta gate | 1–3, 6 | OPEN |
| RISK-005 | Legal and compliance obligations (GDPR, DMCA, illegal-content reporting, EU DSA, ToS/Privacy/AUP, DPA for Team) | M | H | Legal review before public beta (Q-022), data inventory and retention, operator processes | 2–3, 6 | OPEN |
| RISK-006 | Supabase costs from anonymous devices (MAU likely counted; realtime connections) | M | M | No Supabase users for link viewers, lazy sign-in, hidden-tab disconnects, cost alerts, custom-JWT exit ramp | 1, 6 | OPEN |
| RISK-007 | Realtime authorization cached per connection: a device that left a network (or a removed private-room member) keeps receiving ID-only signals until its token refreshes | M | L | ID-only payloads, cooperative unsubscribe on network change, API re-derives the network on every request, presence expires after 10 min, consider 30-min JWT expiry | 1 | ACCEPTED (mitigated) |
| RISK-008 | One-time download can't confirm completion; partial-download bypass; bots consuming links | H if completion-based | M | DEC-015 burn on claim, POST only, no previews | 3 | OPEN |
| RISK-009 | Presigned URLs are bearer tokens and can be forwarded within their TTL | M | L | 60 s TTL, attachment disposition, per-link issuance limits, logging | 1–2 | ACCEPTED (mitigated) |
| RISK-010 | Upload size and type can't be fully enforced before bytes reach R2 (no POST policy) | M | M | Exact size check at completion, delete on mismatch, stale-upload sweep, single-PUT cap 5 GiB, multipart part-count control | 1, 4 | OPEN |
| RISK-011 | R2 behaviour differs from S3 (response-header overrides, batch delete support, lifecycle lag ≈ 24 h) | M | M | Headers set at upload, SP-02 verification, lifecycle only as backstop | 0–3 | OPEN |
| RISK-012 | Storage quota races or drift | M | M | Atomic reservation ledger, daily reconciliation with alerts | 1, 3 | OPEN |
| RISK-013 | Local false negatives: devices on the same Wi-Fi don't see each other (IPv4/IPv6 split, VPN or Private Relay on one device, multi-WAN), or local mode is off (mobile data, most hotspots, large or shared networks) | H | M (UX) | Dual-stack binding (SP-04), clear status copy, link/QR/code fallback (Phase 2), SP-04 measurement | 1–2 | OPEN |
| RISK-014 | Chrome Local Network Access gating WebRTC breaks the optional LAN-proof experiment | — | — | SP-05 withdrawn by CR-001. No design depends on WebRTC. | — | CLOSED |
| RISK-015 | Pricing economics: fixed merchant-of-record fees on $3–5 plans; worst-case storage per plan | H | M | $4–5 plus annual plans, total storage quotas, cost model in [07](07-plans-and-entitlements.md) | 4 | OPEN |
| RISK-016 | Next.js 16 and ecosystem churn (proxy rename, library compatibility with Supabase SSR and shadcn) | M | M | Follow bundled docs, pin versions, SP-03 covers `@supabase/ssr` with `proxy.ts`, Renovate/Dependabot with CI | 0+ | OPEN |
| RISK-017 | Supabase legacy `anon`/`service_role` keys deprecated by end of 2026 | H | L | Use publishable/secret keys from day one, disable legacy keys | 0 | MITIGATING |
| RISK-018 | Janitor deletes the wrong objects (data loss) | L | H | Deletes only from DB-generated outbox rows, key regex, active-share guard, dry-run mode, volume anomaly alerts | 3 | OPEN |
| RISK-019 | Email deliverability for accounts and invitations | M | M | Custom SMTP provider with SPF/DKIM/DMARC, monitoring | 4 | OPEN |
| RISK-020 | Scope and complexity for a small team | H | H | Strict phase gates, Phase 1 scope discipline, defer experiments, reuse Supabase/Cloudflare primitives | All | OPEN |
| RISK-021 | pnpm 12 lockfile or blocked build scripts (sharp, unrs-resolver) break host or CI builds or image optimization | M | M | SP-01 build test, pin a supported pnpm, adjust `allowBuilds` | 0 | OPEN |
| RISK-022 | Latency or data residency from single-region Supabase and R2 location | L | M | Choose region by target market (Q-016). Document subprocessors. | 0 | OPEN |
| RISK-023 | Realtime replay retention (3–4 days) stores whatever is in payloads | L | M | ID-only payloads (DEC-011) | 1 | ACCEPTED (mitigated) |
| RISK-024 | Anonymous → existing-account merge bugs leak or lose memberships and content | M | M | Proof via anonymous token, transactional merge, dedicated tests | 4 | OPEN |
| RISK-025 | Everyone on the same Wi-Fi sees local content, including guests and strangers on café, hotel, office and campus networks. Users may not realize this before posting. | H | H | Audience indicator and one-time notice (DEC-033), "Link only" option (Phase 2), large-network cap, report button, clear Terms and UI copy | 1 | ACCEPTED — inherent to DEC-031 (owner decision) |
| RISK-026 | An ISP reassigns a public IP (or IPv6 prefix), and its next holder sees local content still live on that network key | L | H | Shorter default expiry for local shares (Q-030), fail-closed classification, measure ISP rotation behaviour in SP-04 | 1 | OPEN |

---

## 4. Open questions

Status: `OPEN` · `ANSWERED` (record the answer and date, and update affected decisions).

| ID | Question | Why it matters | Recommendation | Blocks | Status |
|---|---|---|---|---|---|
| Q-001 | Do you accept "discover automatically, admit once, remember" instead of automatic same-network content visibility? | Core product behaviour and security (DEC-002) | — | Phase 1 | **ANSWERED** 2026-09-23: **No.** Keep automatic same-network visibility with no approval step (DEC-031, CR-001). |
| Q-002 | Phase 1 admission methods: approval + nearby PIN + open-join window, with QR pairing in Phase 2? | Scope | — | — | **ANSWERED** 2026-09-23: withdrawn. Local mode has no admission step (CR-001). |
| Q-003 | Who may admit new devices by default: owner only, or any member? | Security vs convenience | — | — | **ANSWERED** 2026-09-23: withdrawn (CR-001) |
| Q-004 | Should rooms be discoverable by default on normal networks, and can every plan turn discovery off? | Privacy defaults | — | — | **ANSWERED** 2026-09-23: withdrawn. There is no discovery. An uploader who doesn't want network visibility chooses "Link only" (DEC-033). |
| Q-005 | In which country is the business registered, and who handles sales tax/VAT? | Billing provider (DEC-023) | Merchant of record unless Stripe plus in-house tax is feasible | Phase 4 | OPEN |
| Q-006 | Final prices: Pro monthly/annual, Team structure (flat vs per-seat)? | Fee economics, entitlements | Pro $5/mo or $48/yr. Team $15/mo incl. 3 seats + $5/seat. | Phase 4–5 | OPEN |
| Q-007 | Storage quotas: Free active storage and daily upload, Pro total, Team pooled? | Cost control | Free 2 GB active + 2 GB/day. Pro 100 GB. Team 250 GB pooled + add-ons. | Phase 1, 4, 5 | OPEN |
| Q-008 | Is one-time download Pro-only (as listed) or also Free? | Plan gates in Phase 3 | Pro-only at paid launch. Optionally enabled for Free during beta. | Phase 3 | OPEN |
| Q-009 | Read-only room links: Pro-only? | Abuse and complexity | Pro-only | Phase 4 | OPEN |
| Q-010 | Executables/scripts in anonymous remote links: block or warn? | Malware distribution | Block until scanning (Phase 6) | Phase 2 | OPEN |
| Q-011 | Ads on Free: drop, or marketing pages only? | Privacy/security (DEC-024) | Drop ads. Use upgrade prompts instead. | Phase 2 | OPEN |
| Q-012 | Hosting budget and willingness to use a VPS (ops work) or Vercel if Hostinger managed Node fails SP-01? | Hosting fallback (DEC-022) | Hostinger VPS + Cloudflare Tunnel | Phase 0 exit | OPEN |
| Q-013 | Cloudflare plan at launch: Free or Pro (more WAF and rate-limit rules)? | Edge protection | Free for staging and alpha. Evaluate Pro before public beta. | Public beta | OPEN |
| Q-014 | Account sign-in methods: email magic link, Google, Apple, passwords? | Auth scope | Magic link + Google first | Phase 4 | OPEN |
| Q-015 | Transfer history retention: Pro and Team? | Storage, privacy | Pro 1 year. Team configurable up to 2 years. | Phase 4–5 | OPEN |
| Q-016 | Primary markets/regions? | Supabase region, R2 location, legal scope | Decide before creating production projects | Phase 0 | OPEN |
| Q-017 | Team retention: allow "no expiry" within quota? Maximum retention? | Storage liability | Allow no expiry within quota. Admins set a maximum. | Phase 5 | OPEN |
| Q-018 | Branded share pages: logo/colours/name on our domain only, or custom domains? | Complexity | Logo/colours/name only. Custom domains later. | Phase 5 | OPEN |
| Q-019 | Browser support baseline? | Next.js 16 minimums (Chrome/Edge/Firefox 111+, Safari 16.4+) | Accept Next.js 16 minimums | Phase 1 | OPEN |
| Q-020 | Product name and production and staging domains? | CORS, CSP, cookies, Turnstile, R2 CORS, email | Decide in Phase 0 | Phase 0 exit | OPEN |
| Q-021 | Who may edit a text item: only its creator, or anyone who can see it? | Collaboration vs vandalism. Under DEC-031 "anyone who can see it" includes strangers on public Wi-Fi. | Local shares: **creator only**; everyone present can copy the text. Private and workspace rooms (Phase 4–5): any member. | Phase 1 | OPEN |
| Q-022 | Who handles abuse reports and legal requests, and who reviews ToS/Privacy/AUP? | Legal readiness | Named operator plus external legal review | Public beta | OPEN |
| Q-023 | Do you accept that Phases 1–2 are internal/invite-only and public beta starts after Phase 3 and the launch gate? | Launch timing | Accept | Phase 1 | OPEN |
| Q-024 | Keep the uncommitted pnpm 12.4.2 bump? | Build compatibility | Decide after SP-01 | Phase 0 | OPEN |
| Q-025 | Are native (mobile/desktop) apps on the long-term roadmap? | The only way to identify the actual LAN (mDNS/Bonjour) instead of the public IP, which would remove RISK-001 for app users | Not now. Revisit after product-market fit. | — | OPEN |
| Q-026 | Billing in Phase 4 (recommended) or Phase 6 (originally proposed)? | Paid launch timing | Phase 4 | Phase 4 | OPEN |
| Q-027 | Should anonymous users be allowed to create remote links at all, or with tighter caps that a verified (free) account lifts? | Abuse vs "no account required" | Phase 2: allow anonymous links under the Free caps in [03 §10](03-security-and-network-design.md#10-rate-limiting-and-abuse-protection) (for example 500 download-URL issuances/day per link, executable block). Phase 4: a free, email-verified account may get higher caps. | Phase 2 | OPEN |
| Q-028 | Should anyone be able to send a remote person a link or QR code to a **whole network's feed**? | It would show other people's local uploads to someone off the network | **No.** Remote links target one share (Free) or a Pro/Team private or workspace room. | Phase 2 | OPEN |
| Q-029 | Large-network cap: switch local mode off above how many distinct devices per 24 h? | Too low breaks offices and cafés. Too high lets an undetected shared IP (campus, carrier NAT) group thousands of strangers. | **50**, configurable, tuned from SP-04 and production data. Fail closed (content hidden) while over the cap. | Phase 1 | OPEN |
| Q-030 | Default expiry for local shares? | A shorter default limits exposure from IP reassignment (RISK-026) and forgotten posts on public Wi-Fi | **24 h default**, with 1 h / 24 h / 7 days selectable on Free (7 days stays the maximum) | Phase 1 | OPEN |

---

## 5. Change records

### CR-001 — Keep automatic same-network visibility (changes DEC-002 and DEC-003)

| Field | Record |
|---|---|
| Date | 2026-09-23 |
| Previous decision | **DEC-002** (PROPOSED): network signals only *suggest* nearby rooms. Content access needs membership, obtained by approval, a nearby PIN, an owner-opened join window, a QR/invite secret or workspace membership, and is remembered across networks. **DEC-003** (PROPOSED): short-lived network hints used only for discovery. |
| Reason for change | **Owner decision.** The core product rule is: on the same Wi-Fi/network, anyone automatically sees uploaded files, text and images; on a different network, nothing is visible automatically; remote access is only through a QR code, link or share code. The owner explicitly declined approval-based sharing. |
| New decision | **DEC-031** (ACCEPTED): automatic same-network visibility. **DEC-032** (PROPOSED): network keys, dual-stack binding and fail-closed eligibility guards. **DEC-033** (PROPOSED): local share permissions and remote reach. DEC-011, DEC-012, DEC-018 and DEC-020 revised to match. |
| Impact on implementation | No code exists, so there is nothing to migrate. Plan changes: <br>• Removed: nearby discovery, admission (approval, PIN, open-join window), LAN-proof auto-admit, SP-05, and the tables `network_observations`, `network_rooms`, `room_join_requests`, `room_pins`, `room_blocks`.<br>• Added: `network_spaces`, `network_presence`, dual-stack binding tables, and share scopes (`network`, `link_only`, `room`).<br>• Moved: rooms, members and invites/QR pairing now start in **Phase 4** with Pro private rooms. Free local mode has no rooms.<br>• Risks: RISK-001 and RISK-002 raised to Critical impact under the new model. RISK-025 and RISK-026 added. RISK-014 closed.<br>• Questions: Q-001 answered; Q-002, Q-003 and Q-004 withdrawn; Q-028, Q-029 and Q-030 added.<br>• Documents updated: 00, 02, 03, 04, 05, 07, 08, 09, 10, README and phases 0–6. |
| Inherent consequences (cannot be designed away) | Everyone on the same Wi-Fi sees local content (RISK-025). Different networks behind one shared IP that is not yet detected can see each other's local content (RISK-001). An ISP reassigning an address can expose content still live on it (RISK-026). The brief's line "public IP must not be treated as authorization" no longer holds for local mode: the Cloudflare-verified network is now the access rule for local content, narrowed by the guards in DEC-032. |
| Migration / rollback plan | None needed (planning only). Reinstating an approval step later would need a new change record and would reintroduce room membership in Phase 1. |
| Approved by | Project owner, by instruction in the planning session, 2026-09-23 |
