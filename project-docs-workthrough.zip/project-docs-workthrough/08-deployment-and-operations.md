# 08 — Deployment and Operations

| Field | Value |
|---|---|
| Document status | PROPOSED — hosting choice is CONDITIONAL on SP-01 (DEC-022) |
| Last updated | 2026-09-23 (CR-001: local-mode configuration and alerts) |
| Key decisions | DEC-004, DEC-017, DEC-022, DEC-028, DEC-029, DEC-030 |

---

## 1. Hosting evaluation

| Option | Advantages | Disadvantages / unknowns | Verdict |
|---|---|---|---|
| **A. Hostinger managed Node.js web app** (Business / Cloud plans) | Owner preference. Low cost. GitHub auto-deploy. Node 18/20/22/24 and npm/yarn/pnpm (auto-detected from lockfile). Environment variables. Restart control. | **Undocumented:** request timeout, response buffering/streaming, headers added or stripped by its front proxy, memory limits (build and runtime), graceful shutdown, outbound TCP ports, log retention. No firewall control, so the origin lock relies on a secret header. It builds on push, so gating needs a deploy branch. pnpm 12 support unverified. | **Conditional** on SP-01 |
| **B. Hostinger VPS** (Docker + Next.js `standalone` + **Cloudflare Tunnel**) | Full control. **No public ingress** (the tunnel dials out). Predictable resources. Can later host a malware-scanner container. Low cost. | You operate OS patching, Docker, monitoring and restarts. A single machine is a single point of failure (acceptable for an MVP with a stateless app). | **Recommended fallback.** Arguably the primary choice if someone can own basic operations. |
| **C. Vercel** | Best Next.js fidelity, preview deployments per PR, trustworthy client-IP headers, integrated cron and logs | Commercial use requires a paid plan. Usage-based pricing. Vendor-specific features. | Fallback if you prefer fully managed hosting over operations |
| **D. Cloudflare Workers via OpenNext** | Same platform as R2 (bindings), native `CF-Connecting-IP`, Cron Triggers, Queues | Next.js 16 adapter maturity must be verified. Runtime and bundle limits. | Re-evaluate in Phase 6 |

### 1.1 SP-01 pass/fail criteria (Hostinger managed Node.js)

| # | Check | Pass condition | If it fails |
|---|---|---|---|
| 1 | Build | `pnpm install --frozen-lockfile` (pinned pnpm) and `next build` succeed on the host. Image optimization works (sharp). | Pin another pnpm version (Q-024). Else B or C. |
| 2 | Runtime | Node 24 (or 22) selectable. App stable for 24 h under light synthetic traffic. | B or C |
| 3 | **Client IP** | Behind Cloudflare, the app receives `CF-Connecting-IP` equal to the real client IP (tested from ≥ 3 networks, IPv4 and IPv6). Client-supplied `CF-Connecting-IP`/`X-Origin-Auth` are overwritten. **Direct requests to the Hostinger origin are rejected by `proxy.ts`.** | **B (Tunnel) or C. Mandatory.** |
| 4 | TLS | Cloudflare **Full (strict)** works with a valid origin certificate | **B or C. Mandatory.** |
| 5 | Streaming | A streamed page shows time-to-first-byte well below total render time (no buffering) | Tolerable for an MVP. Document it. Prefer B. |
| 6 | Request duration | A 30 s route handler completes. Record the maximum. | Acceptable if ≥ 30 s (the API has no long requests) |
| 7 | **Outbound connectivity** | TCP to the Supabase pooler (5432/6543) and HTTPS to the R2 S3 endpoint | Use the DEC-007 RPC fallback, or B |
| 8 | Deploys and restarts | A deploy causes < 10 s of errors. SIGTERM behaviour observed. | Prefer B |
| 9 | Memory | Build fits the plan's limits. RSS stays stable under 50 concurrent requests for 10 min. | Upgrade the plan, or B |
| 10 | Logs | stdout logs accessible, retention known | Ship logs to an external collector |
| 11 | Runtime env | Server-only environment variables are read at runtime, not only at build | Prefer B or C |

The spike result is recorded in `project-docs-workthrough/spikes/SP-01-hostinger.md` and closes DEC-022.

---

## 2. Target topology

### 2.1 Option A — Hostinger managed Node.js

```mermaid
flowchart LR
  U["Users"] --> CF["Cloudflare<br/>proxy, WAF, rate limit, Turnstile<br/>Transform Rule adds X-Origin-Auth"]
  CF --> H["Hostinger Node.js app<br/>Next.js 16 (next start)<br/>proxy.ts rejects requests without X-Origin-Auth"]
  H --> SBP["Supabase pooler (Postgres)"]
  U --> SBR["Supabase Auth + Realtime (direct)"]
  U --> R2["R2 S3 endpoint (presigned PUT/GET)"]
  H -. "presign (local), HEAD, ranged GET, DELETE" .-> R2
  CRON["Supabase Cron"] --> JAN["Edge Function storage-janitor"] --> R2
  GH["GitHub Actions"] -- "fast-forward deploy branch" --> H
  GH -- "supabase db push / functions deploy" --> SBP
```

### 2.2 Option B — Hostinger VPS with Cloudflare Tunnel

```mermaid
flowchart LR
  U["Users"] --> CF["Cloudflare edge"]
  CF <-- "outbound tunnel (no open inbound ports)" --> CFD["cloudflared (VPS)"]
  CFD --> N["Next.js standalone container (VPS)"]
  N --> SBP["Supabase pooler"]
  U --> SBR["Supabase Auth + Realtime"]
  U --> R2["R2 S3 endpoint"]
  CRON["Supabase Cron"] --> JAN["Edge Function storage-janitor"] --> R2
  GH["GitHub Actions"] -- "build image, push to registry, SSH/webhook deploy" --> N
```

---

## 3. Environments

| Aspect | Local | Staging | Production |
|---|---|---|---|
| Web | `next dev` | Separate app or container at `staging.{domain}`, **behind Cloudflare Access** | `app.{domain}` (or apex) |
| Supabase | CLI local stack (Docker), with Mailpit for auth emails | Separate project. Free plan is acceptable but pauses after 1 week inactive, so keep it active or use Pro. | **Pro** plan project in the region chosen by Q-016 |
| R2 | Real dev bucket (scoped token), or MinIO for offline tests | `{product}-files-staging` | `{product}-files-prod` |
| Cloudflare | Not used. Test client-IP override allowed (non-production only). | Proxied + Access + Turnstile (staging keys) | Proxied + WAF + rate limiting + Turnstile (production keys) |
| Billing (Phase 4) | Provider sandbox | Sandbox | Live |
| Data | Seed script | Synthetic only | Real |

---

## 4. Cloudflare configuration checklist

- [ ] DNS records for app hostnames are **proxied**.
- [ ] SSL/TLS **Full (strict)**, Always Use HTTPS, minimum TLS 1.2. HSTS once the domain is final.
- [ ] **Request Header Transform Rule:** set static `X-Origin-Auth: <secret>` on all requests to app hostnames. Rotation procedure documented (two accepted values). Under DEC-031 this rule protects who sees local content: changes to it need review.
- [ ] (If SP-04 adopts them) `v4.` and `v6.` probe hostnames that each answer in only one address family, configured as the SP-04 report specifies.
- [ ] (If SP-04 confirms it works on the chosen plan) a Transform Rule forwarding the client ASN to the origin in a header that `proxy.ts` accepts only together with a valid `X-Origin-Auth`.
- [ ] Cache rules: cache only `/_next/static/*` and hashed public assets. **Bypass** `/api/*`, `/s/*`, `/j/*`, `/c*`, `/rooms/*` and all HTML.
- [ ] Rate limiting rule on `/api/` with a **generous per-IP threshold**, because many users share IPs behind CGNAT. Application limits are the precise layer.
- [ ] Custom WAF rules: allow only expected methods per path prefix. Exempt the billing webhook path from bot challenges.
- [ ] Bot protections: verify they don't challenge API or webhook calls. Tune or disable per path where the plan allows.
- [ ] Turnstile widgets per environment, restricted to that environment's hostnames.
- [ ] Cloudflare Access protects staging (service token for CI smoke tests).
- [ ] Notifications: origin error rate, DDoS alerts, R2 usage.
- [ ] (Option B) Cloudflare Tunnel configured with the ingress rule to the Next.js container.

---

## 5. Supabase configuration checklist

- [ ] Region chosen (Q-016). **Pro** plan for production. Spend and usage alerts configured.
- [ ] API keys: create **publishable** and **secret** keys. Disable legacy `anon`/`service_role` keys once nothing uses them.
- [ ] Data API: exposed schemas exclude `app`. Consider disabling the Data API if nothing uses it (verify Auth and Realtime are unaffected in SP-03).
- [ ] Auth:
  - [ ] Anonymous sign-ins enabled.
  - [ ] **CAPTCHA (Turnstile) enabled.**
  - [ ] JWT expiry reviewed (consider 30 min).
  - [ ] Site URL and redirect allow-list set.
  - [ ] Rate limits reviewed (anonymous sign-ins default 30/h per IP).
  - [ ] Custom SMTP (Phase 4). TOTP MFA enabled (Phase 4).
- [ ] Realtime: **"Allow public access" disabled.** Private channels only.
- [ ] Database:
  - [ ] `app_owner` and `app_server` roles created with strong credentials. SSL enforced.
  - [ ] Network restrictions to the host's egress IPs where static (VPS).
  - [ ] Extensions: `pg_cron`, `pg_net`, `citext`. Vault secret for the janitor trigger.
- [ ] Edge Function `storage-janitor`: `verify_jwt` disabled **only** because the function checks its own trigger secret. Separate R2 token and database role. Secrets set per environment.
- [ ] Backups: daily backups (7 days on Pro). **Point-in-time recovery evaluated before paid launch.** Restore drill on staging before public beta.

---

## 6. R2 configuration checklist

- [ ] One bucket per environment. Location hint per Q-016.
- [ ] Public access **off**. `r2.dev` **off**. No custom domain.
- [ ] CORS per environment: exact app origins; `PUT`, `GET`, `HEAD`; headers `content-type`, `content-disposition`, `cache-control`; expose `ETag`; max age 3600 s.
- [ ] Lifecycle rules: `d7/` 8 days, `d30/` 31 days, `d90/` 91 days, abort incomplete multipart uploads after 1 day, no rule for `ws/`.
- [ ] API tokens: `web-app` and `janitor` (Object Read & Write, scoped to the bucket). No admin tokens in runtime environments.
- [ ] Usage notifications (storage growth, operations).
- [ ] CORS and lifecycle JSON stored in `infra/r2/` and applied from it, so the configuration is reproducible.

---

## 7. CI/CD pipeline

### 7.1 Branches

| Branch | Purpose | Deploys |
|---|---|---|
| `main` | Integration branch, protected (reviews, status checks) | Nothing directly |
| `deploy/staging` | Fast-forwarded by CI after `main` passes and staging migrations apply | Host auto-deploys staging |
| `deploy/production` | Fast-forwarded by the release workflow after approval and production migrations | Host auto-deploys production |

### 7.2 Workflows

| Workflow | Trigger | Steps |
|---|---|---|
| `ci.yml` | PRs and pushes to `main` | 1. Checkout. Node from `.node-version`. pnpm via corepack. `pnpm install --frozen-lockfile`. 2. `pnpm typecheck` and `pnpm lint`. 3. `pnpm test` (unit, coverage). 4. `supabase start`, `supabase db reset`, `supabase test db` (pgTAP). 5. `pnpm test:integration` (local Supabase + MinIO). 6. `pnpm build`. 7. `pnpm test:e2e` (Playwright on `next start` + local stack; the full suite may run nightly). 8. Dependency audit (fail on high/critical). Secret scanning is enabled in the repository. |
| `deploy-staging.yml` | CI success on `main` | `supabase db push` (staging) → `supabase functions deploy` (staging) → fast-forward `deploy/staging` → wait for the host → smoke tests through Cloudflare Access |
| `release.yml` | Manual dispatch or `v*` tag, **environment approval required** | `supabase db push` (production) → functions deploy → fast-forward `deploy/production` → production smoke tests |
| `nightly.yml` | Schedule | Full e2e, real-R2 contract tests against the staging bucket, dependency update PRs (Renovate/Dependabot) |

**Migrations are forward-only.** Expand/contract discipline keeps the previous app version working with the new schema, so rolling back the app means re-pointing the deploy branch to the previous commit.

---

## 8. Observability and alerting

| Signal | Source | Alert when |
|---|---|---|
| Uptime | External monitor on `/api/v1/health` | 2 consecutive failures |
| Cron heartbeat | `/api/v1/health/cron` | Stale > 10 min |
| Server errors | Error monitoring and logs | 5xx rate > 1% over 5 min |
| Janitor backlog | `object_deletions` due rows / oldest age | > 1,000 rows or oldest > 1 h |
| Janitor failures | `attempts ≥ 5` | Any |
| Storage drift | `reconcile-storage-usage` output | Any correction > 1 GB |
| Brute-force signals | Aggregated code, password and unlock failures | 10× baseline |
| Origin-lock rejections | Logs | > 100 per 5 min |
| Network `unavailable` rate | Logs | > 5% of observations (proxy misconfiguration) |
| Network status flips | `network.status_changed` audit events | Spike in spaces becoming `shared_egress` or `too_large` (classification drift or abuse) |
| Abuse reports | `abuse_reports` | Every new report |
| Supabase usage | Supabase dashboard alerts | 80% of MAU, Realtime connections, disk |
| R2 storage | Cloudflare notifications / daily job | > 20% week-over-week growth |
| Billing | `billing_events.status = 'failed'` | Any |

**Redaction is mandatory** in logs and error monitoring (see [03 §14](03-security-and-network-design.md#14-logging-audit-and-security-monitoring)).

---

## 9. Configuration inventory

### 9.1 Public (safe in the browser bundle)

| Variable | Purpose |
|---|---|
| `NEXT_PUBLIC_APP_ORIGIN` | Canonical origin |
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Publishable key |
| `NEXT_PUBLIC_TURNSTILE_SITE_KEY` | Turnstile widget |

### 9.2 Server-only

| Variable | Purpose |
|---|---|
| `APP_ALLOWED_ORIGINS` | Origin allow-list for CSRF checks |
| `TRUST_PROXY_MODE` | `cloudflare` in staging and production, `none` locally |
| `ORIGIN_SHARED_SECRET`, `ORIGIN_SHARED_SECRET_PREVIOUS` | Origin lock |
| `ALLOW_TEST_CLIENT_IP` | Tests only. **The production boot refuses to start if set.** |
| `DATABASE_URL` | `app_server` through the Supavisor pooler |
| `SUPABASE_SECRET_KEY` | Auth admin operations |
| `R2_ACCOUNT_ID`, `R2_BUCKET`, `R2_S3_ENDPOINT`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY` | Storage |
| `NETWORK_KEY_SECRET_CURRENT`, `NETWORK_KEY_SECRET_PREVIOUS`, `NETWORK_KEY_VERSION` | Network keys (DEC-032) |
| `NETWORK_LARGE_CAP` (default 50), `NETWORK_IPV6_PREFIX_LEN` (default 64), `NETWORK_PROBE_HOSTS` (only if the dual-stack probe is adopted) | Local-mode tuning |
| `LINK_PEPPER`, `CODE_PEPPER`, `INVITE_PEPPER`, `PEPPER_VERSION` | Secret hashing |
| `TURNSTILE_SECRET_KEY` | Turnstile verification |
| `LOG_LEVEL` | Logging |
| `SENTRY_DSN` (Phase 6) | Error monitoring |
| `BILLING_*` (Phase 4) | Billing provider credentials and webhook secret |
| `NEXT_SERVER_ACTIONS_ENCRYPTION_KEY` | Only for multi-instance deployments |

Edge Function secrets: `JANITOR_TRIGGER_SECRET`, janitor R2 credentials, janitor database URL.

All variables are validated with zod at boot (`lib/server/env.ts`). `.env.example` lists names only, never values.

---

## 10. Backups and disaster recovery

| Asset | Protection | Target (proposal) |
|---|---|---|
| Postgres | Supabase daily backups (Pro: 7 days). Point-in-time recovery evaluated before paid launch. **Quarterly restore drill** into staging. | RPO ≤ 24 h (≤ minutes with PITR). RTO ≤ 4 h. |
| R2 objects | Ephemeral by design for Free and Pro, so no backups. Team long-retention content relies on R2 durability. Evaluate replication in Phase 6. | — |
| Configuration | Cloudflare rules, R2 CORS and lifecycle, Supabase config, cron definitions (in migrations) documented and versioned in the repo | Rebuild an environment ≤ 1 day |
| Secrets | Stored in provider secret stores. Rotation runbook. | Rotate any secret ≤ 1 h |
| Web tier | Stateless. Redeploy from the Git deploy branch. | RTO ≤ 1 h |

---

## 11. Runbooks to write

| Runbook | Phase |
|---|---|
| Abuse report triage and takedown | 2 |
| Kill switch usage | 2 |
| Janitor backlog / failed deletions | 3 |
| Cron failure / heartbeat stale | 3 |
| Incident response (security and availability) | 3 (before public beta) |
| Secret rotation (each secret in [03 §12](03-security-and-network-design.md#12-secrets-and-key-management)) | 3 |
| Database restore drill | 3 |
| Billing webhook replay and reconciliation | 4 |
| Account and data deletion requests | 4 |
| Workspace suspension and data retention notices | 5 |
