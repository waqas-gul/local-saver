# Phase 0 — Architecture and Foundation

| Field | Value |
|---|---|
| **Status** | **PLANNED** (detailed scope). Awaiting owner approval. Not started. |
| Plan depth | Scope-level plan. A task-by-task plan (test-first, exact files and commands) is written after approval, before implementation. |
| Depends on | Owner review of documents 00–10 |
| Unblocks | Phase 1 |
| Last updated | 2026-09-23 |

---

## 1. Goal

Establish a secure, testable, deployable foundation, and **settle the unverified platform assumptions** that every later phase depends on (hosting and client IP, R2 semantics, Supabase auth and realtime authorization, real-world network grouping). Nothing user-facing ships.

Since CR-001 (automatic same-network visibility), the trusted client IP is the access boundary for local content. The origin lock and SP-01's IP checks are therefore the most security-critical work in this phase, and SP-04 decides how local mode groups networks.

## 2. Scope

| # | Workstream | Contents |
|---|---|---|
| 0.1 | Repository hygiene | Decide pnpm version (after SP-01, Q-024). Rename `master` → `main`. Create the GitHub remote and branch protection. `!.env.example` in `.gitignore`. `engines` + `.node-version` (Node 24 LTS target). `poweredByHeader: false`. Replace template README and page content. |
| 0.2 | Tooling | `typecheck` script, Vitest (unit + component), Playwright (smoke), ESLint rule restricting `lib/server/**` imports to server files, `server-only`, zod-validated environment (`lib/server/env.ts`). Production boot fails if `ALLOW_TEST_CLIENT_IP` is set. |
| 0.3 | UI foundation | shadcn/ui initialization (Tailwind v4), theme tokens in `globals.css`, base layout and metadata, placeholder home page |
| 0.4 | Server skeleton | `proxy.ts`: request ID, **origin lock**, security headers, **CSP with nonce**. `lib/server/http` handler wrapper (error model, JSON only, Origin check, `no-store`). `lib/server/network/client-ip.ts` + `normalize.ts` (unit-tested). `GET /api/v1/health`. `app/robots.ts`. |
| 0.5 | Infrastructure | Domain and hostnames (Q-020). Cloudflare zone (proxy, Full strict TLS, Transform Rule with origin secret, cache bypass rules, one rate-limit rule, Access on staging; `v4.`/`v6.` probe hostnames and an ASN-forwarding rule only if SP-04 adopts them). Supabase staging and production projects (region per Q-016, publishable/secret keys). R2 staging and production buckets (private, CORS, lifecycle from `infra/r2/*.json`, scoped tokens). Turnstile keys per environment. Host environment variables. |
| 0.6 | Database baseline | `app` and `app_realtime` schemas, `app_owner`/`app_server` roles, grants with RLS on by default, extensions (`citext`, `pg_cron`, `pg_net`), `runtime_flags`, `rate_counters`, `app.rate_limit_hit()`. pgTAP baseline tests. Kysely + codegen wired up. |
| 0.7 | CI | `.github/workflows/ci.yml`: install, typecheck, lint, unit, pgTAP (local Supabase), build, Playwright smoke, dependency audit |
| 0.8 | **Spikes** | SP-01 … SP-04 (§4). SP-05 was withdrawn by CR-001. Spike code lives on throwaway branches and is **not merged**. Only the written reports and resulting decisions are. |
| 0.9 | Decision review | Owner reviews the decision log. Each DEC becomes ACCEPTED, CONDITIONAL or REJECTED. Phase 1 blocking questions answered. |

## 3. Existing system state

Unmodified `create-next-app` scaffold (see [01-codebase-audit.md](../01-codebase-audit.md)): Next.js 16.3.5, React 19.2.8, Tailwind 4, ESLint 9, TypeScript 5.9. Branch `master`, no remote, uncommitted pnpm 12.4.2 bump. No backend, database, auth, storage, realtime, CI or security controls.

## 4. Spikes

Each spike has a time box and writes a report to `project-docs-workthrough/spikes/SP-0N-<name>.md` using the template in §4.6.

### SP-01 — Hostinger runtime and trusted client IP (time box: 2 days)

- **Question:** can Hostinger's managed Node.js hosting run this app securely and reliably behind Cloudflare?
- **Method:**
  1. Deploy the Phase 0 app plus a temporary, secret-protected diagnostic endpoint that echoes selected request headers. The endpoint is on the spike branch only.
  2. Put Cloudflare in front and test from at least 3 networks (IPv4 and IPv6).
  3. Hit the origin directly. Send forged `CF-Connecting-IP` and `X-Origin-Auth` headers.
  4. Measure streaming, request-duration ceiling, restart behaviour and memory. Test the pnpm 12 lockfile.
- **Pass/fail criteria:** [08 §1.1](../08-deployment-and-operations.md#11-sp-01-passfail-criteria-hostinger-managed-nodejs). Criteria 3, 4 and 7 are **mandatory**.
- **Decides:** DEC-022 (hosting), DEC-030 (runtime/pnpm), Q-024, parts of DEC-004 and DEC-007.

### SP-02 — R2 direct upload and download semantics (time box: 1.5 days)

- **Question:** does R2 behave as the design assumes?
- **Method:** from a browser on the staging origin:
  - presigned PUT with signed `Content-Type` and `Content-Disposition`
  - a mismatched `Content-Type` (expect 403)
  - `HeadObject` size, and a ranged GET of the first 4,100 bytes
  - presigned GET download on iOS Safari, Android Chrome and desktop (attachment handling, UTF-8 filenames)
  - informational: whether `response-content-disposition` overrides work
  - `DeleteObjects` batch support
  - multipart with equal parts and the `ETag` exposed through CORS
  - lifecycle rules applied from JSON
  - latency measurements
- **Decides:** RISK-011 items, DEC-009/010/026 details, janitor deletion mode.

### SP-03 — Supabase anonymous auth and private Realtime authorization (time box: 2 days)

- **Question:** do the auth and realtime designs work with Next.js 16?
- **Method:**
  - Turnstile-protected `signInAnonymously`.
  - `@supabase/ssr` cookie sessions with `proxy.ts` refresh.
  - Server-side JWT verification (`getClaims`/JWKS): API shape and latency.
  - A private channel with an RLS policy on `realtime.messages` calling an `app_realtime` `SECURITY DEFINER` helper.
  - Client broadcast denied, presence allowed.
  - `realtime.send` from a trigger inside a **rolled-back** transaction (expect no message).
  - Broadcast Replay.
  - Policy re-evaluation after token refresh: how long a device whose presence expired keeps receiving on a `net:` channel.
  - Behaviour with `app` excluded from, or the Data API disabled.
  - Pooler session-mode connection from the host (together with SP-01).
- **Decides:** DEC-005, DEC-006, DEC-011, confirms RISK-007 mitigation, JWT expiry setting.

### SP-04 — Network grouping, dual-stack binding and classification (time box: 3 days)

Under DEC-031 this spike decides **who sees whose local content**, so it is no longer a UX measurement only.

- **Questions:**
  1. How often do network keys put devices on the same Wi-Fi together (true positives), and how often do they put different networks together (false positives)?
  2. Can Cloudflare serve an IPv4-only and an IPv6-only probe hostname for the dual-stack binding ([03 §3.4](../03-security-and-network-design.md#34-dual-stack-binding-conditional-on-sp-04))? What configuration does that need (separate zone, IPv6 compatibility setting, plan)?
  3. Can a Cloudflare rule forward the client's ASN to the origin on the planned plan (Q-013)? Which commercially licensed ASN lists for VPN, hosting and mobile carriers are usable?
  4. How do real ISPs rotate IPv4 addresses and IPv6 prefixes (RISK-026)?
- **Method:**
  - A staging page behind Cloudflare Access where team devices register and see "same space as device X: yes/no" plus `networkStatus`. The server computes HMAC keys. **No raw IPs are stored or shown.**
  - Networks: home dual-stack, home IPv4-only, mobile data, phone hotspot, iCloud Private Relay, commercial VPN, office, café and guest Wi-Fi.
  - Try the probe hostnames. Try an ASN-forwarding rule.
- **Output:**
  - A true/false-positive and false-negative matrix, with and without the dual-stack binding.
  - Go/no-go for the dual-stack probe and for ASN classification in Phase 1.
  - Recommendations for the IPv6 prefix length (/64 vs /56) and the large-network cap (Q-029).
- **Decides:** DEC-032 parameters. Informs RISK-001, RISK-013, RISK-026 and the status copy.

### SP-05 — WebRTC host-candidate LAN proof *(withdrawn)*

Withdrawn by CR-001 on 2026-09-23. It explored WebRTC as an automatic *admission* signal. The accepted model (DEC-031) has no admission step, and WebRTC can't make automatic visibility safer without another device online. RISK-014 is closed.

### 4.6 Spike report template

```markdown
# SP-0N — <title>
Date / author:
Question:
Environment (versions, plans, networks, devices):
Method:
Results (table of each check → pass/fail → evidence link):
Surprises / deviations from documentation:
Decision impact (DEC/RISK/Q IDs and proposed status changes):
Follow-ups:
```

## 5. What will be changed

- Configuration and tooling files, a minimal server skeleton, security headers and the origin lock, the baseline database schema, the CI workflow, infrastructure configuration (Cloudflare, Supabase, R2), and the spike reports.
- Template UI content replaced with a neutral placeholder shell.

## 6. What will NOT be changed

- No local feed, presence, uploads, downloads, links, rooms, accounts, billing or realtime features.
- No production traffic and no public launch. Staging stays behind Cloudflare Access.
- No dependencies beyond those listed in §11.
- No change to accepted architecture without a change record ([06 §1.2](../06-decisions-and-risks.md#12-changing-an-accepted-decision)).

## 7. Architecture decisions involved

DEC-001, DEC-004, DEC-006, DEC-007, DEC-008 (skeleton), DEC-020 (rate-limit function), DEC-022, DEC-028, DEC-029 (logging skeleton), DEC-030. Spikes inform DEC-032, DEC-005, DEC-009, DEC-010, DEC-011, DEC-026. DEC-031 (automatic same-network visibility) is already ACCEPTED.

## 8. Files / modules involved

See [05 §6 — Phase 0](../05-implementation-roadmap.md#phase-0). In summary:

- **Modify:** `package.json`, `pnpm-lock.yaml`, `pnpm-workspace.yaml`, `.gitignore`, `next.config.ts`, `tsconfig.json`, `eslint.config.mjs`, `app/layout.tsx`, `app/page.tsx`, `app/globals.css`, `README.md`.
- **Create:**
  - `.env.example`, `.node-version`, `proxy.ts`, `components.json`, `components/ui/*`, `lib/utils.ts`
  - `lib/server/{env.ts, http/*, network/client-ip.ts, network/normalize.ts, security/crypto.ts, security/ids.ts}`, `lib/server/db/*`
  - `app/api/v1/health/route.ts`, `app/robots.ts`
  - `vitest.config.ts`, `playwright.config.ts`, `tests/unit/**`, `tests/e2e/smoke.spec.ts`
  - `supabase/config.toml`, `supabase/migrations/<ts>_baseline.sql`, `supabase/tests/baseline.test.sql`
  - `infra/r2/{cors.staging.json, cors.production.json, lifecycle.json}`, `infra/cloudflare/README.md` (rule documentation)
  - `.github/workflows/ci.yml`, `project-docs-workthrough/spikes/*`

## 9. Database changes

Baseline migration only: schemas, roles, grants, RLS defaults, extensions, `app.runtime_flags`, `app.rate_counters`, `app.rate_limit_hit()`. See [04 §12](../04-database-and-storage-design.md#12-migration-strategy).

## 10. API changes

`GET /api/v1/health` only: liveness plus optional database readiness, no secrets in the output.

## 11. Dependencies

- **Phase:** owner review of the planning set.
- **Packages (to be approved at task-plan time):** `zod`, `server-only`, `vitest`, `@vitest/coverage-v8`, `@vitejs/plugin-react`, `jsdom`, `@testing-library/react`, `@testing-library/dom`, `@playwright/test`, shadcn/ui-generated dependencies, `supabase` (CLI, dev), `kysely`, `pg`, `kysely-codegen` (dev), `ipaddr.js`.
- **Accounts:** GitHub, Cloudflare (domain), Supabase (2 projects), R2 enabled, Hostinger (plan per SP-01).

## 12. Security considerations

- The origin lock and trusted-IP logic are security-critical and fully unit-tested. **Under DEC-031 they decide who sees local content**, so any doubt about the host's header handling blocks Phase 1. Production refuses the test IP and ASN overrides.
- Secrets are generated per environment, stored only in provider secret stores, and validated at boot.
- Staging is protected by Cloudflare Access.
- Spike diagnostic endpoints are secret-protected, live only on spike branches, and are deleted afterwards.
- Legacy Supabase keys are not used (RISK-017).

## 13. Testing requirements

- Unit tests: `client-ip` (trusted and untrusted modes, header precedence, production override refusal), `normalize` (T-006, T-007), crypto helpers (HMAC, timing-safe compare, random IDs), env validation, the HTTP wrapper (Origin check T-046 basics, error mapping, `no-store`).
- pgTAP: client roles cannot access `app`. `rate_limit_hit` allows exactly *limit* calls per window.
- E2E smoke: the home page renders with a CSP nonce and without `X-Powered-By` (T-048).
- CI must be green on a pull request.

## 14. Acceptance criteria

| ID | Criterion | Evidence |
|---|---|---|
| AC-0.1 | `main` on GitHub with branch protection. CI green on a PR (typecheck, lint, unit, pgTAP, build, e2e smoke, audit). | PR link, CI run |
| AC-0.2 | Frozen-lockfile install and build succeed in CI and on the chosen host, with pinned Node/pnpm | CI logs, SP-01 report |
| AC-0.3 | Staging behind Cloudflare and Access: `/api/v1/health` returns 200. Headers include CSP with a nonce, `nosniff`, `frame-ancestors 'none'`, the referrer policy, and no `X-Powered-By`. | Header capture |
| AC-0.4 | Origin lock verified: direct origin requests get 403, forged client headers are overwritten or ignored (T-008) | SP-01 report |
| AC-0.5 | `client-ip` and normalization unit tests pass, including the production boot refusal | CI run |
| AC-0.6 | Supabase staging and production exist with publishable/secret keys. `app` is not exposed. Baseline migration applied to staging. pgTAP grant tests pass. | Screenshots, CI run |
| AC-0.7 | R2 buckets private, CORS and lifecycle applied from `infra/r2/*.json`, scoped tokens created | Config export, SP-02 report |
| AC-0.8 | SP-01 … SP-04 reports written with pass/fail. SP-04 records the dual-stack and ASN go/no-go decisions. | Spike files |
| AC-0.9 | Owner reviewed the decision log (each DEC ACCEPTED/CONDITIONAL/REJECTED). Phase 1 blocking questions answered: Q-012, Q-016, Q-019, Q-020, Q-021, Q-023, Q-024, Q-029, Q-030. (Q-001 is answered; Q-002–Q-004 were withdrawn by CR-001.) | Updated [06](../06-decisions-and-risks.md) |
| AC-0.10 | `.env.example` lists every Phase 0–1 variable. Missing variables fail fast at boot. | Test + file |

## 15. Known risks

RISK-001 (measured in SP-04), RISK-002 (spoofing), RISK-003 (Hostinger unknowns), RISK-016 (framework churn), RISK-017 (legacy keys), RISK-021 (pnpm/build scripts), RISK-022 (region).

## 16. Open questions

Q-012 (hosting fallback budget), Q-013 (Cloudflare plan, which may affect ASN forwarding), Q-016 (region), Q-020 (name/domain), Q-024 (pnpm), plus the Phase 1 blockers listed in AC-0.9.

## 17. Implementation status

| Date | Status | Note |
|---|---|---|
| 2026-09-17 | PLANNED | Scope plan drafted from the repository audit. Awaiting owner review. |
| 2026-09-23 | PLANNED | CR-001: SP-04 widened (dual-stack binding, ASN forwarding, ISP rotation; 3 days). SP-05 withdrawn. Phase 1 blocking questions updated. |

### Verification record

*Empty until the phase is verified. Record each AC with evidence links, the owner's sign-off, and the date.*
